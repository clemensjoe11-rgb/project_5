import type { Express } from "express";
import { createServer, type Server } from "http";
import { contactFormSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = contactFormSchema.parse(req.body);
      
      const emailContent = `
New Contact Form Submission from TRADURAN Website

Name: ${validatedData.name}
Email: ${validatedData.email}
Phone: ${validatedData.phone || 'Not provided'}
Service: ${validatedData.service}

Message:
${validatedData.message}

---
Sent from TRADURAN Contact Form
      `.trim();

      console.log('\n=== NEW CONTACT FORM SUBMISSION ===');
      console.log(emailContent);
      console.log('===================================\n');

      res.json({ 
        success: true, 
        message: 'Message received successfully',
        emailTo: 'a.d@traduran.lu',
        note: 'Email would be sent to a.d@traduran.lu in production'
      });
    } catch (error) {
      console.error('Contact form error:', error);
      res.status(400).json({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Invalid form data' 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
